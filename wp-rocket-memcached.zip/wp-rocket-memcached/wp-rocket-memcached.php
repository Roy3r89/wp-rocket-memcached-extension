<?php
/**
 * Plugin Name: WP Rocket Memcached
 * Description: Extiende WP Rocket para usar Memcached con purga avanzada, interfaz administrativa y soporte multi-servidor.
 * Version: 1.1
 * Author: Roy3r
 * Text Domain: wp-rocket-memcached
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

add_action( 'plugins_loaded', function() {
    load_plugin_textdomain( 'wp-rocket-memcached', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

// Aquí incluiría la clase principal y el manejo del cache, cola de purga, cron, etc.
// Para este ejemplo, asumimos que el código completo ya está cargado y funciona correctamente.

// Incluir la interfaz administrativa
require_once plugin_dir_path( __FILE__ ) . 'admin-ui.php';

// Instancia global para uso en admin-ui.php
$GLOBALS['wp_rocket_memcached_cache'] = new class {
    public function load_settings() {
        $this->settings = get_option( 'wp_rocket_memcached_settings', [
            'ttl' => 3600,
            'prefix' => 'wp_rocket_cache_',
            'servers' => [ ['127.0.0.1', 11211] ]
        ] );
    }
    public function get_stats() {
        return [
            'reads' => 1000,
            'hits' => 800,
            'misses' => 200,
        ];
    }
    public function get_server_statuses() {
        return [
            ['server' => '127.0.0.1:11211', 'active' => true, 'response_time_ms' => 1],
        ];
    }
    public function clear_all_cache() {
        // Simulación
        return true;
    }
    public function load_settings() {
        $this->settings = get_option( 'wp_rocket_memcached_settings', [
            'ttl' => 3600,
            'prefix' => 'wp_rocket_cache_',
            'servers' => [ ['127.0.0.1', 11211] ]
        ] );
    }
};

$GLOBALS['wp_rocket_memcached_cache']->load_settings();
