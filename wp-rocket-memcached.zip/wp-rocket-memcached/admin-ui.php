<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', function() {
    add_menu_page(
        __( 'WP Rocket Memcached', 'wp-rocket-memcached' ),
        __( 'WP Rocket Memcached', 'wp-rocket-memcached' ),
        'manage_options',
        'wp-rocket-memcached',
        'wp_rocket_memcached_admin_page',
        'dashicons-admin-generic'
    );
} );

function wp_rocket_memcached_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'No tienes permiso para acceder a esta página.', 'wp-rocket-memcached' ) );
    }

    $cache = $GLOBALS['wp_rocket_memcached_cache'] ?? null;
    if ( ! $cache ) {
        echo '<div class="notice notice-error"><p>' . esc_html__( 'El sistema de Memcached no está disponible.', 'wp-rocket-memcached' ) . '</p></div>';
        return;
    }

    // Guardar configuración
    if ( isset( $_POST['wp_rocket_memcached_save'] ) && check_admin_referer( 'wp_rocket_memcached_save_action', 'wp_rocket_memcached_nonce' ) ) {
        $ttl = absint( $_POST['ttl'] );
        $prefix = sanitize_text_field( $_POST['prefix'] );
        $servers = [];

        if ( isset($_POST['servers']) && is_array($_POST['servers']) ) {
            foreach ( $_POST['servers'] as $server ) {
                $parts = explode(':', $server);
                if ( count($parts) === 2 && filter_var( trim($parts[0]), FILTER_VALIDATE_IP ) && is_numeric( $parts[1] ) ) {
                    $servers[] = [ trim($parts[0]), intval($parts[1]) ];
                }
            }
        }

        update_option( 'wp_rocket_memcached_settings', [
            'ttl' => $ttl,
            'prefix' => $prefix,
            'servers' => $servers,
        ] );

        echo '<div class="notice notice-success"><p>' . esc_html__( 'Configuración guardada correctamente.', 'wp-rocket-memcached' ) . '</p></div>';

        // Recargar settings después de guardar
        $cache->load_settings();
    }

    // Limpiar caché completa
    if ( isset( $_POST['wp_rocket_memcached_clear'] ) && check_admin_referer( 'wp_rocket_memcached_clear_action', 'wp_rocket_memcached_clear_nonce' ) ) {
        $cache->clear_all_cache();
        echo '<div class="notice notice-success"><p>✅ ' . esc_html__( 'Caché Memcached limpiada correctamente.', 'wp-rocket-memcached' ) . '</p></div>';
    }

    // Vaciar cola purga
    if ( isset($_POST['wp_rocket_memcached_clear_queue']) && check_admin_referer( 'wp_rocket_memcached_clear_queue_action', 'wp_rocket_memcached_clear_queue_nonce' ) ) {
        update_option( 'wp_rocket_memcached_purge_queue', [] );
        echo '<div class="notice notice-success"><p>✅ ' . esc_html__( 'Cola de purga limpiada manualmente.', 'wp-rocket-memcached' ) . '</p></div>';
    }

    // Descargar log
    if ( isset($_POST['wp_rocket_memcached_download_log']) && check_admin_referer( 'wp_rocket_memcached_download_log_action', 'wp_rocket_memcached_download_log_nonce' ) ) {
        $upload_dir = wp_upload_dir();
        $log_file = trailingslashit( $upload_dir['basedir'] ) . 'memcached.log';

        if ( file_exists($log_file) ) {
            header('Content-Description: File Transfer');
            header('Content-Type: text/plain');
            header('Content-Disposition: attachment; filename="memcached.log"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($log_file));
            readfile($log_file);
            exit;
        } else {
            echo '<div class="notice notice-error"><p>' . esc_html__( 'No se encontró el archivo de log.', 'wp-rocket-memcached' ) . '</p></div>';
        }
    }

    // Obtener configuración actual para mostrar
    $settings = get_option( 'wp_rocket_memcached_settings', [
        'ttl' => 3600,
        'prefix' => 'wp_rocket_cache_',
        'servers' => [ ['127.0.0.1', 11211] ]
    ] );

    $stats = $cache->get_stats();

    global $wpdb;
    $index_table = $wpdb->prefix . 'wp_rocket_memcached_cache_index';
    $total_keys = $wpdb->get_var( "SELECT COUNT(*) FROM {$index_table}" );

    $purge_queue = get_option( 'wp_rocket_memcached_purge_queue', [] );

    // Leer últimas 50 líneas del log
    $upload_dir = wp_upload_dir();
    $log_file = trailingslashit( $upload_dir['basedir'] ) . 'memcached.log';
    $log_lines = [];
    if ( file_exists($log_file) ) {
        $log_lines = array_slice( file( $log_file ), -50 );
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'WP Rocket Memcached - Panel de Administración', 'wp-rocket-memcached' ); ?></h1>

        <h2><?php esc_html_e( 'Estado del sistema', 'wp-rocket-memcached' ); ?></h2>
        <table class="widefat striped">
            <tr><th><?php esc_html_e( 'Total de claves cacheadas:', 'wp-rocket-memcached' ); ?></th><td><?php echo intval($total_keys); ?></td></tr>
            <tr><th><?php esc_html_e( 'Claves en cola para purgar:', 'wp-rocket-memcached' ); ?></th><td><?php echo count($purge_queue); ?></td></tr>
        </table>

        <h2><?php esc_html_e( 'Estadísticas de Caché', 'wp-rocket-memcached' ); ?></h2>
        <table class="widefat striped">
            <tr><th><?php esc_html_e( 'Total Lecturas', 'wp-rocket-memcached' ); ?></th><td><?php echo intval($stats['reads']); ?></td></tr>
            <tr><th><?php esc_html_e( 'Hits (aciertos)', 'wp-rocket-memcached' ); ?></th><td><?php echo intval($stats['hits']); ?></td></tr>
            <tr><th><?php esc_html_e( 'Misses (fallos)', 'wp-rocket-memcached' ); ?></th><td><?php echo intval($stats['misses']); ?></td></tr>
            <tr><th><?php esc_html_e( 'Ratio Hit (%)', 'wp-rocket-memcached' ); ?></th>
                <td><?php
                    $ratio = $stats['reads'] > 0 ? round( ( $stats['hits'] / $stats['reads'] ) * 100, 2 ) : 0;
                    echo $ratio . '%';
                ?></td>
            </tr>
        </table>

        <h2><?php esc_html_e( 'Estado de servidores Memcached', 'wp-rocket-memcached' ); ?></h2>
        <form method="post" style="margin-bottom: 1em;">
            <?php wp_nonce_field( 'wp_rocket_memcached_test_connection_action', 'wp_rocket_memcached_test_connection_nonce' ); ?>
            <button type="submit" name="test_connection" class="button"><?php esc_html_e( 'Probar conexión manual', 'wp-rocket-memcached' ); ?></button>
        </form>

        <table class="widefat striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Servidor (IP:Puerto)', 'wp-rocket-memcached' ); ?></th>
                    <th><?php esc_html_e( 'Estado', 'wp-rocket-memcached' ); ?></th>
                    <th><?php esc_html_e( 'Tiempo de respuesta (ms)', 'wp-rocket-memcached' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $statuses = $cache->get_server_statuses();
                foreach ( $statuses as $status ) :
                    ?>
                    <tr>
                        <td><?php echo esc_html( $status['server'] ); ?></td>
                        <td><?php echo $status['active'] ? '✅ ' . esc_html__( 'Activo', 'wp-rocket-memcached' ) : '❌ ' . esc_html__( 'Inactivo', 'wp-rocket-memcached' ); ?></td>
                        <td><?php echo esc_html( $status['response_time_ms'] ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h2><?php esc_html_e( 'Configuración', 'wp-rocket-memcached' ); ?></h2>
        <form method="post">
            <?php wp_nonce_field( 'wp_rocket_memcached_save_action', 'wp_rocket_memcached_nonce' ); ?>

            <table class="form-table">
                <tr>
                    <th scope="row"><label for="ttl"><?php esc_html_e( 'TTL (segundos)', 'wp-rocket-memcached' ); ?></label></th>
                    <td><input name="ttl" type="number" id="ttl" value="<?php echo esc_attr( $settings['ttl'] ); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="prefix"><?php esc_html_e( 'Prefijo de clave', 'wp-rocket-memcached' ); ?></label></th>
                    <td><input name="prefix" type="text" id="prefix" value="<?php echo esc_attr( $settings['prefix'] ); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label><?php esc_html_e( 'Servidores Memcached', 'wp-rocket-memcached' ); ?></label></th>
                    <td>
                        <div id="servers-wrapper">
                            <?php foreach ( $settings['servers'] as $server ): ?>
                                <input type="text" name="servers[]" value="<?php echo esc_attr( implode(':', $server) ); ?>" class="regular-text" required><br>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="button" onclick="addServer()"><?php esc_html_e( '+ Añadir servidor', 'wp-rocket-memcached' ); ?></button>
                        <p class="description"><?php esc_html_e( 'Formato: IP:PUERTO (ej. 127.0.0.1:11211)', 'wp-rocket-memcached' ); ?></p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" name="wp_rocket_memcached_save" class="button-primary"><?php esc_html_e( 'Guardar cambios', 'wp-rocket-memcached' ); ?></button>
            </p>
        </form>

        <h2><?php esc_html_e( 'Herramientas', 'wp-rocket-memcached' ); ?></h2>
        <form method="post" style="margin-bottom:1em;">
            <?php wp_nonce_field( 'wp_rocket_memcached_clear_action', 'wp_rocket_memcached_clear_nonce' ); ?>
            <button name="wp_rocket_memcached_clear" class="button button-secondary" onclick="return confirm('<?php esc_attr_e( '¿Estás seguro de que deseas borrar TODA la caché Memcached?', 'wp-rocket-memcached' ); ?>')">🧹 <?php esc_html_e( 'Limpiar toda la caché', 'wp-rocket-memcached' ); ?></button>
        </form>

        <form method="post" style="margin-bottom:1em;">
            <?php wp_nonce_field( 'wp_rocket_memcached_clear_queue_action', 'wp_rocket_memcached_clear_queue_nonce' ); ?>
            <button name="wp_rocket_memcached_clear_queue" class="button button-secondary" onclick="return confirm('<?php esc_attr_e( '¿Estás seguro de vaciar la cola de purga pendiente?', 'wp-rocket-memcached' ); ?>')">🗑️ <?php esc_html_e( 'Vaciar cola de purga', 'wp-rocket-memcached' ); ?></button>
        </form>

        <form method="post" style="margin-bottom:1em;">
            <?php wp_nonce_field( 'wp_rocket_memcached_download_log_action', 'wp_rocket_memcached_download_log_nonce' ); ?>
            <button name="wp_rocket_memcached_download_log" class="button">📥 <?php esc_html_e( 'Descargar Log', 'wp-rocket-memcached' ); ?></button>
        </form>

        <h2><?php esc_html_e( 'Últimas líneas del log', 'wp-rocket-memcached' ); ?></h2>
        <pre style="max-height:300px; overflow:auto; background:#f5f5f5; padding:10px; border:1px solid #ccc;"><?php
            if ( empty($log_lines) ) {
                echo esc_html__( "No hay registros aún.", 'wp-rocket-memcached' );
            } else {
                echo esc_html( implode( '', $log_lines ) );
            }
        ?></pre>

    </div>

    <script>
        function addServer() {
            const wrapper = document.getElementById('servers-wrapper');
            const input = document.createElement('input');
            input.type = 'text';
            input.name = 'servers[]';
            input.className = 'regular-text';
            input.placeholder = '127.0.0.1:11211';
            wrapper.appendChild(input);
            wrapper.appendChild(document.createElement('br'));
        }
    </script>

    <style>
        pre {
            font-family: monospace;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
    </style>
    <?php
}
