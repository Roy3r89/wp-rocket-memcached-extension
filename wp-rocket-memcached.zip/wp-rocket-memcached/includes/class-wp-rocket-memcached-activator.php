<?php
// includes/class-wp-rocket-memcached-activator.php

if ( ! defined( 'ABSPATH' ) ) exit;

class WPRocketMemcachedActivator {

    /**
     * Acciones a realizar al activar el plugin.
     */
    public static function activate() {
        // Asegurarse de que la clase WPRocketMemcachedCache esté cargada.
        // object-cache.php puede que aún no esté activo, así que la cargamos aquí.
        require_once WP_ROCKET_MEMCACHED_PATH . 'includes/class-wp-rocket-memcached-cache.php';

        // Intentar usar la instancia global si ya está disponible (ej. si object-cache.php está cargado)
        // o crear una nueva instancia ligera solo para logging.
        global $wp_rocket_memcached_cache;
        $cache_instance = $wp_rocket_memcached_cache ?? new WPRocketMemcachedCache( false ); // 'false' para no intentar inicializar Memcached en el constructor si es solo para log.

        $cache_instance->log( __( 'Iniciando proceso de activación del plugin WP Rocket Memcached.', 'wp-rocket-memcached' ), 'info' );

        // Intentar crear la tabla de índice de caché.
        self::create_cache_index_table( $cache_instance ); // Pasa la instancia de log.

        // Programar los cron jobs.
        self::schedule_purge_cron();
        self::schedule_stats_collection_cron();

        $cache_instance->log( __( 'Proceso de activación del plugin WP Rocket Memcached finalizado.', 'wp-rocket-memcached' ), 'info' );
    }

    /**
     * Intenta crear la tabla de índice de caché si no existe.
     *
     * @param WPRocketMemcachedCache $cache_instance Instancia del logger para registrar eventos.
     */
    private static function create_cache_index_table( $cache_instance ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rocket_memcached_cache_index';

        $charset_collate = $wpdb->get_charset_collate();

        // Definición de la tabla.
        // 'cache_key' es la clave única para cada URL/objeto cacheado.
        // 'last_modified' es la fecha de la última modificación del contenido para purga condicional.
        // 'object_type' podría ser 'post', 'page', 'category', 'tag', 'user', 'comment' o 'global'.
        // 'object_id' es el ID del objeto específico (post ID, category ID, etc.).
        // 'associated_keys' es un JSON de otras claves de caché que deben purgarse con este objeto.
        // 'created_at' y 'updated_at' para seguimiento.
        $sql = "CREATE TABLE $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            cache_key varchar(255) NOT NULL UNIQUE,
            last_modified datetime DEFAULT NULL,
            object_type varchar(50) DEFAULT NULL,
            object_id bigint(20) unsigned DEFAULT NULL,
            associated_keys text DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY cache_key (cache_key),
            KEY object_type_id (object_type,object_id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

        // Verificar si la tabla fue creada o actualizada exitosamente.
        $result = $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" );
        if ( $result === $table_name ) {
            $cache_instance->log( __( 'Tabla de índice de caché verificada/creada correctamente.', 'wp-rocket-memcached' ), 'info' );
        } else {
            $cache_instance->log( sprintf( __( 'Error al crear la tabla de índice de caché: %s', 'wp-rocket-memcached' ), print_r( $wpdb->last_error, true ) ), 'error' );
            // También puedes loguear el resultado de dbDelta si quieres más detalles.
            // $result_dbdelta = dbDelta( $sql ); // dbDelta no devuelve un valor que puedas loguear fácilmente así.
            // $cache_instance->log( sprintf( __( 'Resultado dbDelta al crear la tabla de índice de caché: %s', 'wp-rocket-memcached' ), print_r( $result, true ) ), 'info' );
        }
    }

    /**
     * Programa el cron para procesar la cola de purga.
     */
    private static function schedule_purge_cron() {
        if ( ! wp_next_scheduled( 'wp_rocket_memcached_purge_cron' ) ) {
            wp_schedule_event( time(), 'hourly', 'wp_rocket_memcached_purge_cron' ); // Ejecutar cada hora
        }
    }

    /**
     * Programa el cron para recolectar estadísticas diarias.
     */
    private static function schedule_stats_collection_cron() {
        if ( ! wp_next_scheduled( 'wp_rocket_memcached_collect_stats_cron' ) ) {
            wp_schedule_event( time(), 'daily', 'wp_rocket_memcached_collect_stats_cron' ); // Ejecutar diariamente
        }
    }
}