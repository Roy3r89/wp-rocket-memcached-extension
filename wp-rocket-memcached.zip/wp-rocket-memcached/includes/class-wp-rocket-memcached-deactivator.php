<?php
// includes/class-wp-rocket-memcached-deactivator.php

if ( ! defined( 'ABSPATH' ) ) exit;

class WPRocketMemcachedDeactivator {

    /**
     * Acciones a realizar al desactivar el plugin.
     */
    public static function deactivate() {
        // Asegurarse de que la clase WPRocketMemcachedCache esté cargada para el logging.
        // Se hace require_once aquí porque este archivo se ejecuta durante la desactivación,
        // y necesitamos la funcionalidad de log.
        require_once WP_ROCKET_MEMCACHED_PATH . 'includes/class-wp-rocket-memcached-cache.php';

        // Intentar usar la instancia global si ya está disponible (ej. si object-cache.php está cargado)
        // o crear una nueva instancia ligera solo para logging.
        global $wp_rocket_memcached_cache;
        $cache_instance = $wp_rocket_memcached_cache ?? new WPRocketMemcachedCache( false ); // 'false' para no intentar inicializar Memcached en el constructor si es solo para log.

        $cache_instance->log( __( 'Iniciando proceso de desactivación del plugin WP Rocket Memcached.', 'wp-rocket-memcached' ), 'info' );

        // Desprogramar los cron jobs registrados por el plugin.
        self::unschedule_purge_cron();
        self::unschedule_stats_collection_cron();

        // Opcional: Eliminar opciones del plugin de la base de datos al desactivar.
        // Comenta o descomenta estas líneas según si quieres que la configuración
        // y estadísticas se conserven al desactivar el plugin.
        delete_option( 'wp_rocket_memcached_settings' );
        delete_option( 'wp_rocket_memcached_daily_stats' );
        delete_option( 'wp_rocket_memcached_purge_queue' );

        // Opcional: Eliminar la tabla de índice de caché de la base de datos.
        // Si descomentas esto, la tabla se borrará al desactivar.
        // self::drop_cache_index_table(); // Requiere la función drop_cache_index_table si existe.

        // Eliminar el archivo de log del plugin.
        $upload_dir = wp_upload_dir();
        $log_file = trailingslashit( $upload_dir['basedir'] ) . 'memcached.log';
        if ( file_exists( $log_file ) ) {
            unlink( $log_file );
        }

        $cache_instance->log( __( 'Proceso de desactivación del plugin WP Rocket Memcached finalizado.', 'wp-rocket-memcached' ), 'info' );
    }

    /**
     * Desprograma el cron para procesar la cola de purga.
     */
    private static function unschedule_purge_cron() {
        $timestamp = wp_next_scheduled( 'wp_rocket_memcached_purge_cron' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'wp_rocket_memcached_purge_cron' );
        }
    }

    /**
     * Desprograma el cron de recolección de estadísticas.
     */
    private static function unschedule_stats_collection_cron() {
        $timestamp = wp_next_scheduled( 'wp_rocket_memcached_collect_stats_cron' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'wp_rocket_memcached_collect_stats_cron' );
        }
    }

    // Si tu plugin tiene una función para eliminar la tabla de índice de caché,
    // puedes incluirla aquí y llamarla en deactivate(). Por ejemplo:
    /*
    private static function drop_cache_index_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rocket_memcached_cache_index';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
    }
    */
}