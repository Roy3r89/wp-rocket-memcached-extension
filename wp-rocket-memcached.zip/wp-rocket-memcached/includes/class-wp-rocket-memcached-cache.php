<?php
// includes/class-wp-rocket-memcached-cache.php

if ( ! defined( 'ABSPATH' ) ) exit;

// Asegúrate de que esta clase extiende WP_Object_Cache si lo hace tu instalación base de WordPress.
// Si tu plugin está diseñado como un drop-in directo para object-cache.php que maneja sus propias funciones wp_cache_*,\r\n// entonces no necesita extender WP_Object_Cache. Basado en el object-cache.php que creaste,\r\n// parece que tu clase maneja las funciones wp_cache_* directamente.\r\n// Si tu clase necesita los métodos base de WP_Object_Cache, entonces debe extenderla.\r\n// De lo contrario, puedes omitir \"extends WP_Object_Cache\".
class WPRocketMemcachedCache {

    private $memcached;
    public $settings;
    private $log_file; // Ahora se inicializará de forma perezosa.
    private $is_memcached_available = false;

    // Grupos de caché global de WordPress.
    private $global_groups = [];

    // Grupos de caché que no deben ser persistentes (almacenados solo en memoria durante la petición).
    private $non_persistent_groups = [];

    /**
     * Constructor de la clase.
     *
     * @param bool $initialize_memcached Si es true, intenta conectar con Memcached en el constructor.
     * Útil para el Activator que solo necesita el método log.
     */
    public function __construct( $initialize_memcached = true ) {
        // La inicialización del log_file ahora se hace de forma perezosa en el método log().

        // === CRÍTICO: SE ELIMINÓ LA CARGA DE CONFIGURACIÓN AQUÍ ===
        // La carga de configuración se ha movido a wp_cache_init() en object-cache.php
        // para evitar la dependencia circular con wp_cache_get().
        // $this->load_settings(); // ESTA LÍNEA FUE ELIMINADA.

        // Inicializa Memcached solo si es el contexto adecuado (no solo para loguear desde el activador).
        if ( $initialize_memcached ) {
            // El initialize_memcached ahora ya no llama a load_settings() desde aquí.
            // Se asume que load_settings() se llamará explícitamente desde object-cache.php
            // una vez que el entorno de WordPress esté más inicializado.
            // $this->initialize_memcached(); // Ya no se llama aquí directamente.
        }

        // Hooks para los cron jobs.
        add_action( 'wp_rocket_memcached_purge_cron', [ $this, 'process_purge_queue' ] );
        add_action( 'wp_rocket_memcached_collect_stats_cron', [ $this, 'collect_and_store_stats' ] );
    }

    /**
     * Inicializa el archivo de log si aún no está definido.
     */
    private function ensure_log_file_path() {
        if ( empty( $this->log_file ) ) {
            $upload_dir = wp_upload_dir();
            $this->log_file = trailingslashit( $upload_dir['basedir'] ) . 'memcached.log';
        }
    }

    /**
     * Carga la configuración del plugin desde la base de datos.
     */
    public function load_settings() {
        // Verificar si las funciones de opciones de WordPress están disponibles.
        if ( ! function_exists( 'get_option' ) ) {
            $this->log( __( 'Error al cargar la configuración: las funciones de opciones de WordPress no están disponibles.', 'wp-rocket-memcached' ), 'error' );
            return;
        }

        $this->settings = get_option( 'wp_rocket_memcached_settings', [
            'ttl' => 3600, // Tiempo de vida predeterminado en segundos (1 hora).
            'prefix' => 'wp_rocket_cache_', // Prefijo predeterminado para las claves de caché.
            'servers' => [ ['127.0.0.1', 11211] ] // Servidor Memcached predeterminado.
        ] );
    }

    /**
     * Inicializa la conexión con el servidor Memcached.
     * Debería ser llamado después de que las configuraciones sean cargadas.
     * Ya no carga settings si no están presentes. Se asume que settings ya fueron cargados.
     */
    public function initialize_memcached() {
        if ( $this->is_memcached_available ) {
            return; // Ya inicializado.
        }

        // La carga de la configuración se ha movido fuera de aquí.
        // Se asume que load_settings() ha sido llamado explícitamente antes de llamar a initialize_memcached().
        if ( empty( $this->settings ) ) {
            // Si las settings aún están vacías, registra un error pero no intentes cargarlas aquí para evitar bucles.
            $this->log( __( 'Error: La configuración de Memcached está vacía al intentar inicializar.', 'wp-rocket-memcached' ), 'error' );
            $this->is_memcached_available = false;
            return;
        }

        if ( ! class_exists( 'Memcached' ) ) {
            $this->log( __( 'La extensión PHP Memcached no está instalada o habilitada.', 'wp-rocket-memcached' ), 'error' );
            $this->is_memcached_available = false;
            return;
        }

        try {
            $this->memcached = new Memcached();
            $this->memcached->setOption( Memcached::OPT_BINARY_PROTOCOL, true );
            $this->memcached->setOption( Memcached::OPT_NO_BLOCK, true ); // Para no bloquear si un servidor está caído.
            $this->memcached->setOption( Memcached::OPT_TCP_NODELAY, true ); // Deshabilita el algoritmo de Nagle.
            $this->memcached->setOption( Memcached::OPT_CONNECT_TIMEOUT, 100 ); // ms
            $this->memcached->setOption( Memcached::OPT_POLL_TIMEOUT, 100 ); // ms
            $this->memcached->setOption( Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT );
            $this->memcached->setOption( Memcached::OPT_LIBKETAMA_COMPATIBLE, true ); // Compatibilidad con Ketama para hashing.

            $added_any_server = false;
            foreach ( $this->settings['servers'] as $server ) {
                $host = $server[0] ?? '127.0.0.1';
                $port = $server[1] ?? 11211;
                // Evitar añadir el mismo servidor dos veces si ya está en la lista.
                if ( ! in_array( [$host, $port], $this->memcached->getServerList() ) ) {
                     if ( $this->memcached->addServer( $host, $port ) ) {
                         $added_any_server = true;
                     } else {
                         $this->log( sprintf( __( 'No se pudo añadir el servidor Memcached: %s:%d', 'wp-rocket-memcached' ), $host, $port ), 'warning' );
                     }
                }
            }

            if ( ! $added_any_server && empty( $this->memcached->getServerList() ) ) {
                 $this->log( __( 'Ningún servidor Memcached pudo ser añadido. La caché de objetos no funcionará.', 'wp-rocket-memcached' ), 'error' );
                 $this->is_memcached_available = false;
                 return;
            }

            $this->is_memcached_available = true;
            $this->log( __( 'Conexión con Memcached establecida.', 'wp-rocket-memcached' ), 'info' );

        } catch ( Exception $e ) {
            $this->log( sprintf( __( 'Error al conectar con Memcached: %s', 'wp-rocket-memcached' ), $e->getMessage() ), 'error' );
            $this->is_memcached_available = false;
        }
    }

    /**
     * Agrega un servidor Memcached.
     *
     * @param string $host
     * @param int $port
     * @return bool
     */
    public function add_server( $host, $port ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }
        $added = $this->memcached->addServer( $host, $port );
        if ( $added ) {
            $this->log( sprintf( __( 'Servidor Memcached añadido: %s:%d', 'wp-rocket-memcached' ), $host, $port ), 'info' );
        } else {
            $this->log( sprintf( __( 'Fallo al añadir servidor Memcached: %s:%d', 'wp-rocket-memcached' ), $host, $port ), 'warning' );
        }
        return $added;
    }

    /**
     * Obtiene estadísticas de Memcached.
     *
     * @return array|false
     */
    public function get_stats() {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }
        return $this->memcached->getStats();
    }

    /**
     * Obtiene el estado de los servidores Memcached.
     *
     * @return array
     */
    public function get_server_statuses() {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return [];
        }
        $server_list = $this->memcached->getServerList();
        $statuses = [];
        foreach ( $server_list as $server ) {
            $host = $server['host'];
            $port = $server['port'];
            try {
                // Ping el servidor para verificar si está activo.
                // Memcached::getVersion() es una buena forma de probar la conexión.
                $version = $this->memcached->getVersion();
                $active = isset( $version["{$host}:{$port}"] ) && $version["{$host}:{$port}"] !== false;
                $statuses[] = [
                    'server' => "{$host}:{$port}",
                    'active' => $active,
                    // Memcached PHP extension doesn't easily provide direct response time per server.
                    // Esto es solo un valor de ejemplo o se requeriría un ping manual.
                    'response_time_ms' => 0 // Placeholder
                ];
            } catch ( Exception $e ) {
                $statuses[] = [
                    'server' => "{$host}:{$port}",
                    'active' => false,
                    'response_time_ms' => 0,
                    'error' => $e->getMessage()
                ];
            }
        }
        return $statuses;
    }


    /**
     * Limpia toda la caché de Memcached.
     * Esto es el equivalente a wp_cache_flush().
     *
     * @return bool
     */
    public function clear_all_cache() {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            $this->log( __( 'Intentó limpiar la caché, pero Memcached no está disponible.', 'wp-rocket-memcached' ), 'warning' );
            return false;
        }

        $result = $this->memcached->flush();
        if ( $result ) {
            $this->log( __( 'Caché de Memcached vaciada completamente.', 'wp-rocket-memcached' ), 'info' );
        } else {
            $this->log( __( 'Fallo al vaciar la caché de Memcached.', 'wp-rocket-memcached' ), 'error' );
        }
        return $result;
    }

    /**
     * Agrega un valor a la caché si la clave no existe.
     * Equivalente a wp_cache_add().
     *
     * @param string $key La clave a almacenar.
     * @param mixed $data Los datos a almacenar.
     * @param string $group El grupo de caché.
     * @param int $expire El tiempo de expiración en segundos.
     * @return bool True en éxito, false en fallo.
     */
    public function add( $key, $data, $group = '', $expire = 0 ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }

        $real_key = $this->get_prefixed_key( $key, $group );
        $ttl = $this->get_ttl( $expire );

        // Memcached add() devuelve false si la clave ya existe.
        return $this->memcached->add( $real_key, $data, $ttl );
    }

    /**
     * Cierra la conexión de la caché. No es estrictamente necesario para Memcached.
     * Equivalente a wp_cache_close().
     *
     * @return bool Siempre true.
     */
    public function close() {
        // Memcached PHP extension no requiere un método explícito para cerrar.
        // Las conexiones se gestionan automáticamente o se cierran al final de la petición.
        return true;
    }

    /**
     * Decrementa un valor numérico en caché.
     * Equivalente a wp_cache_decr().
     *
     * @param string $key La clave a decrementar.
     * @param int $offset La cantidad a decrementar.
     * @param string $group El grupo de caché.
     * @return int|false Nuevo valor en éxito, false en fallo.
     */
    public function decr( $key, $offset = 1, $group = '' ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }
        $real_key = $this->get_prefixed_key( $key, $group );
        return $this->memcached->decrement( $real_key, $offset );
    }

    /**
     * Elimina una clave de la caché.
     * Equivalente a wp_cache_delete().
     *
     * @param string $key La clave a eliminar.
     * @param string $group El grupo de caché.
     * @return bool True en éxito, false en fallo.
     */
    public function delete( $key, $group = '' ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }
        $real_key = $this->get_prefixed_key( $key, $group );
        return $this->memcached->delete( $real_key );
    }

    /**
     * Obtiene un valor de la caché.
     * Equivalente a wp_cache_get().
     *
     * @param string $key La clave a obtener.
     * @param string $group El grupo de caché.
     * @param bool $force Si es true, omite la caché interna.
     * @param bool $found Se establece a true si la clave fue encontrada, false en caso contrario.
     * @return mixed Los datos en éxito, false en fallo.
     */
    public function get( $key, $group = '', $force = false, &$found = null ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            $found = false;
            return false;
        }

        $real_key = $this->get_prefixed_key( $key, $group );
        $value = $this->memcached->get( $real_key );

        if ( $this->memcached->getResultCode() === Memcached::RES_NOTFOUND ) {
            $found = false;
            return false;
        }

        $found = true;
        return $value;
    }

    /**
     * Incrementa un valor numérico en caché.
     * Equivalente a wp_cache_incr().
     *
     * @param string $key La clave a incrementar.
     * @param int $offset La cantidad a incrementar.
     * @param string $group El grupo de caché.
     * @return int|false Nuevo valor en éxito, false en fallo.
     */
    public function incr( $key, $offset = 1, $group = '' ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }
        $real_key = $this->get_prefixed_key( $key, $group );
        return $this->memcached->increment( $real_key, $offset );
    }

    /**
     * Reemplaza un valor existente en la caché.
     * Equivalente a wp_cache_replace().
     *
     * @param string $key La clave a reemplazar.
     * @param mixed $data Los nuevos datos.
     * @param string $group El grupo de caché.
     * @param int $expire El tiempo de expiración en segundos.
     * @return bool True en éxito, false en fallo.
     */
    public function replace( $key, $data, $group = '', $expire = 0 ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }
        $real_key = $this->get_prefixed_key( $key, $group );
        $ttl = $this->get_ttl( $expire );
        return $this->memcached->replace( $real_key, $data, $ttl );
    }

    /**
     * Almacena un valor en la caché.
     * Equivalente a wp_cache_set().
     *
     * @param string $key La clave a almacenar.
     * @param mixed $data Los datos a almacenar.
     * @param string $group El grupo de caché.
     * @param int $expire El tiempo de expiración en segundos.
     * @return bool True en éxito, false en fallo.
     */
    public function set( $key, $data, $group = '', $expire = 0 ) {
        if ( ! $this->is_memcached_available || ! $this->memcached ) {
            return false;
        }
        $real_key = $this->get_prefixed_key( $key, $group );
        $ttl = $this->get_ttl( $expire );
        return $this->memcached->set( $real_key, $data, $ttl );
    }

    /**
     * Cambia al contexto de un blog específico para la caché.
     * Importante para instalaciones multisitio.
     * Equivalente a wp_cache_switch_to_blog().
     *
     * @param int $blog_id El ID del blog.
     */
    public function switch_to_blog( $blog_id ) {
        // En Memcached, el prefijo de clave ya maneja la segregación entre blogs.
        // Aseguramos que el prefijo se actualice con el ID del nuevo blog.
        if ( ! empty( $this->settings['prefix'] ) ) {
            $this->settings['prefix'] = $this->get_base_prefix() . $blog_id . '_';
        }
        // También podemos necesitar actualizar los grupos globales aquí si hay alguna lógica específica.
    }

    /**
     * Agrega grupos a la lista de grupos globales.
     *
     * @param array|string $groups Un grupo o un array de grupos.
     */
    public function add_global_groups( $groups ) {
        if ( ! is_array( $groups ) ) {
            $groups = (array) $groups;
        }
        $this->global_groups = array_unique( array_merge( $this->global_groups, $groups ) );
    }

    /**
     * Agrega grupos a la lista de grupos no persistentes (solo en memoria).
     * Nota: Memcached es inherentemente persistente, este método podría no tener un efecto directo
     * o requeriría lógica interna adicional para una "cache in-memory" dentro de PHP.
     * Para Memcached, simplemente no se almacenan en el backend si son "no-persistentes",
     * pero para fines de compatibilidad de API, lo incluimos.
     *
     * @param array|string $groups Un grupo o un array de grupos.
     */
    public function add_non_persistent_groups( $groups ) {
        if ( ! is_array( $groups ) ) {
            $groups = (array) $groups;
        }
        $this->non_persistent_groups = array_unique( array_merge( $this->non_persistent_groups, $groups ) );
    }

    /**
     * Obtiene la clave con prefijo para Memcached.
     *
     * @param string $key La clave original.
     * @param string $group El grupo de caché.
     * @return string La clave prefijada.
     */
    private function get_prefixed_key( $key, $group ) {
        // Para grupos globales, no se usa el prefijo de blog.
        if ( in_array( $group, $this->global_groups, true ) ) {
            return $this->settings['prefix'] . $group . ':' . $key;
        }

        // Para instalaciones multisitio, el prefijo del blog es crucial.
        if ( is_multisite() && ! empty( $this->settings['prefix'] ) ) {
             // El prefijo ya debería incluir el ID del blog si switch_to_blog() se usó.
             // Si no, podríamos necesitar get_blog_prefix() aquí.
            return $this->settings['prefix'] . $group . ':' . $key;
        }

        return $this->settings['prefix'] . $group . ':' . $key;
    }

    /**
     * Calcula el TTL (Time To Live) para la clave.
     *
     * @param int $expire El tiempo de expiración proporcionado.
     * @return int El TTL final.
     */
    private function get_ttl( $expire ) {
        if ( $expire <= 0 ) {
            return $this->settings['ttl']; // Usar el TTL predeterminado del plugin.
        }
        return $expire;
    }

    /**
     * Obtiene el prefijo base de la caché (antes de añadir el ID del blog para multisitio).
     *
     * @return string
     */
    private function get_base_prefix() {
        if ( ! empty( $this->settings['prefix'] ) && is_multisite() ) {
            // Elimina el prefijo del blog actual para obtener el prefijo base.
            // Esto es una suposición basada en cómo se podría generar el prefijo en switch_to_blog().
            // Si el prefijo se genera de forma diferente, esta lógica puede necesitar ajuste.
            $current_blog_id = get_current_blog_id();
            $blog_prefix_len = strlen( $current_blog_id . '_' );
            if ( substr( $this->settings['prefix'], -$blog_prefix_len ) === $current_blog_id . '_' ) {
                return substr( $this->settings['prefix'], 0, -$blog_prefix_len );
            }
        }
        return $this->settings['prefix'];
    }


    /**
     * Procesa la cola de purga de caché.
     * Este método es llamado por un cron job.
     */
    public function process_purge_queue() {
        // Implementa la lógica para purgar URLs o claves específicas de la caché.
        // Esto podría implicar leer una cola de la base de datos o de otra caché.
        $this->log( __( 'Procesando cola de purga de caché.', 'wp-rocket-memcached' ), 'info' );
        // Ejemplo: Obtener ítems de la cola de purga y eliminarlos de Memcached.
        // Esto requeriría una tabla de base de datos o una clave de caché específica para la cola de purga.
    }

    /**
     * Recolecta y almacena estadísticas diarias.
     * Este método es llamado por un cron job.
     */
    public function collect_and_store_stats() {
        if ( ! function_exists( 'get_option' ) || ! function_exists( 'update_option' ) ) {
            $this->log( __( 'Error al recolectar estadísticas: las funciones de opciones de WordPress no están disponibles.', 'wp-rocket-memcached' ), 'error' );
            return;
        }

        $stats = $this->get_stats(); // Obtiene las estadísticas brutas de Memcached.

        if ( empty( $stats ) ) {
            $this->log( __( 'No se pudieron obtener estadísticas de Memcached para la recolección diaria.', 'wp-rocket-memcached' ), 'warning' );
            return;
        }

        $daily_stats = get_option( 'wp_rocket_memcached_daily_stats', [] );
        $today = date( 'Y-m-d' );

        // Sumar estadísticas de todos los servidores si hay varios.
        $total_stats = [];
        foreach ( $stats as $server_stats ) {
            if ( is_array( $server_stats ) ) {
                foreach ( $server_stats as $key => $value ) {
                    if ( is_numeric( $value ) ) {
                        $total_stats[ $key ] = ( $total_stats[ $key ] ?? 0 ) + $value;
                    }
                }
            }
        }

        // Almacenar las estadísticas totales del día.
        $daily_stats[ $today ] = $total_stats;

        // Mantener solo un cierto número de días (ej. 30 días).
        $daily_stats = array_slice( $daily_stats, -30, null, true );

        update_option( 'wp_rocket_memcached_daily_stats', $daily_stats );
        $this->log( __( 'Estadísticas diarias de Memcached recolectadas y almacenadas.', 'wp-rocket-memcached' ), 'info' );
    }

    /**
     * Escribe un mensaje en el archivo de log.
     *
     * @param string $message El mensaje a loguear.
     * @param string $level El nivel de log (info, warning, error).
     */
    public function log( $message, $level = 'info' ) {
        // Asegurarse de que la ruta del archivo de log esté definida.
        $this->ensure_log_file_path();

        if ( ! $this->log_file || ! is_writable( dirname( $this->log_file ) ) ) {
            // Si no podemos escribir en el archivo de log, intentar error_log de PHP como fallback.
            error_log( 'WP Rocket Memcached Log Error: ' . $message );
            return;
        }

        $timestamp = current_time( 'mysql' );
        $log_entry = "[{$timestamp}] [" . strtoupper( $level ) . "] {$message}\\n";
        file_put_contents( $this->log_file, $log_entry, FILE_APPEND | LOCK_EX );
    }

    /**
     * Obtiene las últimas líneas del archivo de log.
     *
     * @param int $num_lines Número de líneas a obtener.
     * @return array Array de cadenas, cada una es una línea del log.
     */
    public function get_last_log_lines( $num_lines = 50 ) {
        $this->ensure_log_file_path(); // Asegura que el path esté inicializado.

        if ( ! file_exists( $this->log_file ) || ! is_readable( $this->log_file ) ) {
            return [];
        }
        $file_content = file( $this->log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
        return array_slice( $file_content, -$num_lines );
    }

    /**
     * Descarga el archivo de log.
     */
    public function download_log_file() {
        $this->ensure_log_file_path(); // Asegura que el path esté inicializado.

        if ( ! file_exists( $this->log_file ) || ! is_readable( $this->log_file ) ) {
            wp_die( __( 'El archivo de log no existe o no se puede leer.', 'wp-rocket-memcached' ) );
        }

        $filename = 'wp-rocket-memcached-log-' . date( 'Ymd' ) . '.log';

        header( 'Content-Type: application/octet-stream' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Expires: 0' );
        header( 'Cache-Control: must-revalidate' );
        header( 'Pragma: public' );
        header( 'Content-Length: ' . filesize( $this->log_file ) );
        readfile( $this->log_file );
        exit;
    }
}